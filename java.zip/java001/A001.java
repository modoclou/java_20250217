package com.company.java001;

public class A001 {
	public static void main(String [] args) {
		System.out.println("Hello");
	} // end main
} // end class


//  한줄 주석(설명글)
/*  ctrl +   (화면크게)  / ctrl -  (화면작게)

3번째줄 : public class A001{   
     public   아무데서나 접근가능 / class    부품객체  / A001     클래스이름 
4번째줄 : jvm 구동시작점 
     public static void main(String [] args){}
     public   아무데서나 접근가능 /  static 메모리상사용가능 / void main(String [] arg) 전원버튼이름  
5번째줄 : System.out.println("Hello");
     System (운영체제)  out( cmd ) println( 출력)
     
  ctrl + f11 ( 실행 )     
 */
