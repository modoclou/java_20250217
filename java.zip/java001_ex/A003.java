package com.company.java001_ex;

public class A003 {
	public static void main(String [] args) {
		System.out.println("A");
		System.out.println("AB");
		System.out.println("ABC");
		
		System.out.println("A\nAB\nABC");   // \n 줄바꿈
	}
}
