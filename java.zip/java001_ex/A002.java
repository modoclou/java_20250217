package com.company.java001_ex;

public class A002 {
	public static void main(String [] args) {
		System.out.println("내 이름은 안효정입니다.");
	}
}
