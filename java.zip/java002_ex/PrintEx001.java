package com.company.java002_ex;

public class PrintEx001 {
	public static void main(String[] args) {
		//1. println
		System.out.println("좋아하는 색상은 RED입니다.");
		//2. print + \n  -> println 
		System.out.print("좋아하는 색상은 RED입니다.\n");
		
		//3. ★  printf   %s  
		System.out.printf("좋아하는 색상은 %s입니다.", "red");
	}
}
/*
연습문제1)  
패키지명 : com.company.java002_ex
클래스명 : PrintEx001
출력내용 : 
   %s를 이용해서  다음과 같이 출력
   
    좋아하는 색상은 RED입니다.

  

*/